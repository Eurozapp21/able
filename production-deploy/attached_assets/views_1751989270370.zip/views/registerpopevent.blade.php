<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">

    <div class="modal-dialog modal-lg modal-dialog-centered euz_model_lg" role="document">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title" id="">Registration Form</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">

                    <span aria-hidden="true">&times;</span>

                </button>

            </div>

            <form class="popmodalfrmevent" method="post" action="{{ url('/store') }}" onSubmit="return popmodalevent();">
                {{ csrf_field() }}
                <div class="modal-body">							
                    <div class="row border p-3 m-2 nextmod1">
                        <div class="col-md-12">
							<h5 class="font-weight-bold" id="">Participant Details  </h5><hr>
						</div>
						<input type="hidden" name="headingtype" value=3 />
						<input type="hidden" name="headingid" value="<?php echo $event[0]->id; ?>" />
						<div class="form-group col-lg-3 col-md-4">
                            <input type="radio" class="" id="eushow" name="citi" required value="EU Citizen" /><label for="" class="ml-2">EU Citizen</label><span style="color: #fbdc00;"> *</span>
                        </div>
                        <div class="form-group col-lg-6 col-md-4 yesno">
                            <label class="mr-2 euz_wi">Do you have Vat Number?</label>
                            <input type="radio" class="" id="eushowyes" name="dovatno" value="1" onclick="showhavingvatno()" /><label for="" class="ml-2">Yes</label><span style="color: #fbdc00;"> *</span>
                            <input type="radio" class="" id="eushowno" name="dovatno"  value="2" onclick="hidehavingvatno()" /><label for="" class="ml-2">No</label><span style="color: #fbdc00;"> *</span>
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <input type="radio" class="" id="euhide" name="citi" required value="Non-EU Citizen" /><label for="" class="ml-2">Non-EU Citizen</label><span style="color: #fbdc00;"> *</span>
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="" class="eudiv">VAT Number</label><span style="color: #fbdc00;" class="eudiv"> *</span>
                            <input type="text" class="form-control eudiv" id="vatno" name="vatno"  />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="" class="eudiv">Re-Enter VAT Number</label><span style="color: #fbdc00;" class="eudiv"> *</span>
                            <input type="text" class="form-control eudiv" id="revatno" name="revatno"  />
                        </div>
						
						
						
						
						
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Name</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" class="form-control" id="fname" name="fname" required />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Surname</label>
                            <input type="text" class="form-control" id="" name="lname" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Title</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" class="form-control" id="title" name="title" required  value="<?php echo $modtit;?>" readonly />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Company/ Org</label>
                            <input type="text" class="form-control" id="" name="org" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Address</label>
                            <input type="text" class="form-control" id="" name="address" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">City</label>
                            <input type="text" class="form-control" id="" name="city" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Τ.Κ./Postal code</label>
                            <input type="text" class="form-control" id="" name="postcode" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Country</label>
                            <input type="text" class="form-control" id="" name="country" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Tel.</label>
                            <input type="text" class="form-control IsNumberFields" id="" name="phone" onkeypress="return isNumberKey(event)" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Fax</label>
                            <input type="text" class="form-control" id="" name="fax" />
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Mobile</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" class="form-control" id="mobile" name="mobile" required onkeypress="return isNumberKey(event)"/>
                        </div>
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Email</label><span style="color: #fbdc00;"> *</span>
                            <input type="email" class="form-control IsEmailFields" id="email" name="email" required />
                        </div>                      
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Password</label><span style="color: #fbdc00;"> *</span>
                            <input type="password" class="form-control" id="txtPassword" name="pass" required />
                        </div>
                        <div class="form-group col-lg-3 col-md-4" >
                            <label for="">Re-Enter Password</label><span style="color: #fbdc00;"> *</span>
                            <input type="password" class="form-control" id="txtConfirmPassword" name="conpass" />
                        </div> 
                        <div class="col-md-12">
							<input type="checkbox" name="discheck" id="discheck" style="margin-left: 10px;" /> I need invoice
						</div>
                    </div>
                    <div class="row border p-3 m-2 nextmod1 secform" style="display: none;">
						<div class="col-md-12">
							<h5 class="font-weight-bold" id="">Στοιχεία Τιμολογίου / Invoice Information</h5><hr>
						</div>
					
                        <div class="form-group col-lg-3 col-md-4">
                            <label for="">Organization Name</label>
                            <input type="text" class="form-control" id="" name="orgname">
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="">Address 1</label>
                            <input type="text" class="form-control" id="" name="address1">
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="">Address 2</label>
                            <input type="text" class="form-control" id="" name="address2">
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="">T.I.C</label>
                            <input type="text" class="form-control" id="" name="tic">
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="">Others</label>
                            <input type="text" class="form-control" id="" name="day">
                        </div>
						<div class="form-group col-lg-3 col-md-4">
                            <label for="">Occupation</label>
                            <input type="text" class="form-control" id="" name="occu">
                        </div>
                    </div>
                    <div class="row border p-3 m-2 nextmod2">
						<div class="col-md-12">
							<h5 class="font-weight-bold" id="">Payment Method</h5><hr>
						</div>
						<div class="col-lg-8 pad0">
                            <div class="form-group col-lg-12 col-md-4">
                                <div class="custom-control custom-radio custom-control-inline" onclick="show3();">
    								<input type="radio" class="custom-control-input cash" id="customRadio" name="tratype" value="Cash Payment" required>
    								<label class="custom-control-label" for="customRadio">Cash Payment</label>
    							</div>
    							<div class="custom-control custom-radio custom-control-inline" onclick="show3();">
    								<input type="radio" class="custom-control-input bank" id="customRadio2" name="tratype" value="Bank Transaction">
    								<label class="custom-control-label" for="customRadio2">Bank Transaction</label>
    							</div>
    							<div class="custom-control custom-radio custom-control-inline" onclick="show3();">
    								<input type="radio" class="custom-control-input online" id="customRadio3" name="tratype" value="Online">
    								<label class="custom-control-label" for="customRadio3">Online</label>
    							</div>
                            </div>
    						<div class="form-group col-lg-12" id="ful">
                                <div class="custom-control custom-radio custom-control-inline" onclick="show1();">
    								<input type="radio" class="custom-control-input" id="fullamount" name="paytype" value="Full Payment" required>
    								<label class="custom-control-label" for="fullamount">Full Payment</label>
    							</div>
    							<?php if(!empty($event[0]->firstamt)) {?>
    							<div class="custom-control custom-radio custom-control-inline" onclick="show2();">
    								<input type="radio" class="custom-control-input" id="halfamount" name="paytype" value="Half Payment">
    								<label class="custom-control-label" for="halfamount">Deposit</label>
    							</div>
    								<?php }?>
                            </div>
    						<div class="form-group col-lg-3 col-md-4" id="fullpa">
                                <label for="">Full Payment</label>
                                
                                <!--<input type="text" class="form-control" id="" name="fullamt" value="<?php //if(!empty($event[0]->fee)) { 
                                    
                                //echo number_format((float)$payableamt, 2, '.', '');
                                //} ?>" readonly>-->
                                
                                <input type="hidden" id="hidpa" value="<?php echo number_format((float)$payableamt, 2, '.', '');?>" />
                                <input type="hidden" id="hidvatper" value="<?php echo round($vatper,2) ;?>" />
                                
                                <input type="hidden" id="citizentype" value="" />
                                <input type="hidden" id="hidvatno" value="" />
                                <input type="hidden" id="fullpaymenttype" value="" />
                                <input type="text" class="form-control" id="hidfullpay" name="fullamt" value="" readonly>
                           <!--<input type="text" class="form-control" id="" name="fullamt" value="<?php //if(!empty($event[0]->fee)) { 
                                    
                                //echo number_format((float)$payableamt, 2, '.', '');
                                //} ?>" readonly> -->    
                                
                                <input type="hidden" class="form-control" id="" name="ids" value="<?php echo $event[0]->id; ?>">
                                <input type="hidden" class="form-control" id="" name="page" value="Event">
                                <input type="hidden" class="form-control" id="" name="title" value="<?php echo $event[0]->title; ?>">
                            </div>
    						<div class="form-group col-lg-3 col-md-4" id="fullpa1">
                                <b for="" class="font-weight">Half Payment</b>
                                <input type="text" class="form-control" id="" name="halfamt" value="<?php if(!empty($event[0]->fee)) { echo $event[0]->firstamt; } ?>" readonly>
                            </div>
    						<div class="form-group col-lg-12 col-md-12" id="fullpa1comt">
                                <p class="text-justify mb-0"><?php if(!empty($event[0]->fee)) { echo $event[0]->firstdesc; } ?></p>
                            </div>
    						<div class="form-group col-lg-3 col-md-4" id="fullpa11">
                                <b for="" class="font-weight">Balance Standing Amount</b>
                                <input type="text" class="form-control" id="" name="balamt" value="<?php if(!empty($event[0]->fee)) { //echo $event[0]->secondamt;
                                echo number_format((float)$balamt, 2, '.', '');
                                
                                } ?>" readonly>
                            </div>
    						<div class="form-group col-lg-12 col-md-12" id="fullpa1comt1">
                                <p class="text-justify"><?php if(!empty($event[0]->fee)) { echo $event[0]->seconddesc; } ?></p>
                            </div>
                        </div>
                        <div class="col-lg-4 form-group cashdis" style="display: none;">
                            <label for="">Cash Payment Details</label>
                            <textarea type="text" class="form-control" id="" rows="5" name=""><?php echo $event[0]->cash; ?></textarea>    
                        </div>
                        <div class="col-lg-4 form-group bankdis" style="display: none;">
                            <label for="">Bank Transaction Details</label>
                            <textarea type="text" class="form-control" id="" rows="5" name=""><?php echo $event[0]->bank; ?></textarea>    
                        </div>
                        <div class="col-lg-4 form-group onlinedis" style="display: none;">
                            <img class="img-fluid w-50" src="<?php echo url('/../Content/image/paypal.png'); ?>" />  
                        </div>
						<div class="form-group col-lg-12">
                            <label for="">Comment</label>
                            <textarea type="text" class="form-control" id="" rows="5" name="comment"></textarea>
                        </div>
					</div>
                </div>
                <div class="modal-footer">
                    <input type="checkbox" name="terms" id="terms" style="margin-left: 10px;" /> I Accept Terms and Conditions
                    <button type="button" class="btn btn-cardbutn ml-2" data-dismiss="modal" style="border-radius: 50px;">Cancel</button>
                    <button type="button" class="btn btn-cardbutn ml-2 nextmod subterms" style="display: none;">Next</button>
					<button type="button" class="btn btn-cardbutn ml-2 nextmod22">Back</button>
					<button type="submit" class="btn btn-cardbutn ml-2 nextmod21" id="btnSubmit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="confirmmodallogevent">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header p-2">
          <button type="button" class="close" data-dismiss="modal" onclick="subfrmevent();">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body text-center" style="font-family: sans-serif;">
          <h3>Congratulations <span class="txtname"></span></h3>
          <h4>You're REGISTERED.</h4>
          <i class="fas fa-check-circle my-3" style="font-size: 6rem;color: #fbdc00;"></i>
          <h6>IMPORTANT! Check Your Inbox for more details.</h6>
          <h6>We sent it to <b><span class="txtemail"></span></b></h6>
		  <h6>Don't see it? Be sure to check your junk or promotional folder.</h6>
        </div>
        
        <!-- Modal footer -->
        <div class="modal-footer d-none">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
        
      </div>
    </div>
</div>




<script>
$(".yesno").hide();
$(".eudiv").hide();
$(document).ready(function() {
    $("#eushow").click(function(){
    	//$(".eudiv").show();
    	$("#citizentype").val(1);
    	$(".yesno").show();
    });
    $("#euhide").click(function(){
    $("#citizentype").val(2);
    	$(".eudiv").hide();
    	$(".yesno").hide();
    });
});


$("#eushowyes").click(function(){
    	$(".eudiv").show();
    });
    $("#euhideno").click(function(){
    	$(".eudiv").hide();
    });


function popmodalevent(){
        var email = $("#email").val();
        $('.txtemail').html(email);
        var fname = $("#fname").val();
        $('.txtname').html(fname);
        var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) 
            {
                alert("Passwords do not match.");
                return false;
            }
            else{
        $('#confirmmodallogevent').modal('show');
            }
    }






    $(function () 
    {
       /* $("#btnSubmit").click(function () 
        {
            var password = $("#txtPassword").val();
            var confirmPassword = $("#txtConfirmPassword").val();
            if (password != confirmPassword) 
            {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });*/
        $("#discheck").click(function () 
		{
			if ($(this).is(":checked")) 
			{
				$(".secform").show();
			} 
			else 
			{
				$(".secform").hide();
			}
		});
		$(".cash").click(function () 
		{
			if ($(this).is(":checked")) 
			{
				$(".cashdis").show();
				$(".bankdis").hide();
				$(".onlinedis").hide();
			} 
			else 
			{
				$(".cashdis").hide();
				$(".bankdis").show();
			}
		});
		$(".bank").click(function () 
		{
			if ($(this).is(":checked")) 
			{
				$(".cashdis").hide();
				$(".bankdis").show();
				$(".onlinedis").hide();
			} 
			else 
			{
				$(".cashdis").show();
				$(".bankdis").hide();
			}
		});
		$(".online").click(function () 
		{
			if ($(this).is(":checked")) 
			{
				$(".cashdis").hide();
				$(".bankdis").hide();
				$(".onlinedis").show();
			} 
			else 
			{
				$(".onlinedis").hide();
			}
		});
		$("#terms").click(function () 
		{
			if ($(this).is(":checked")) 
			{
				$(".subterms").show();
			} 
			else 
			{
				$(".subterms").hide();
			}
		});
    });
    function isNumberKey(evt)
    {
        var charCode = (evt.which) ? evt.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
        return true;
    }
    $(".nextmod22, .nextmod2, .nextmod21").hide();	
    $(".nextmod").click(function()
    {
        var fname = $("#fname").val();
        var title = $("#title").val();
        var mobile = $("#mobile").val();
        var email = $("#email").val();
        var password = $("#txtPassword").val();
        var confirmPassword = $("#txtConfirmPassword").val();
        var vatno=$("#vatno").val();
        var revatno=$("#revatno").val();
     
        if(fname == '') 
        {
            alert("Name filed is required.");
            return false;
        }
        if(title == '') 
        {
            alert("Title filed is required.");
            return false;
        }
        if(mobile == '') 
        {
            alert("Mobile filed is required.");
            return false;
        }
        if(email == '') 
        {
            alert("Email filed is required.");
           // $(".nextmod2").hide();
            return false;
        }
        if(password == '') 
        {
            alert("Passwords do not match.");
            return false;
        }
        if(password != confirmPassword) 
        {
            alert("Passwords do not match.");
            return false;
        }
        
        var vtexist=$("#hidvatno").val();
         if (vtexist==1){
             if (vatno==''){
                 alert("Please enter Vat Number");
                 return false;
             }
         }
        
        
         if(vatno != revatno) 
        {
            alert("Vat Number does not match.");
            return false;
        }
        
        //new code
        var fullpaymenttype=$("#fullpaymenttype").val();
        if (fullpaymenttype==1){
        var hidvatper=$("#hidvatper").val();
    var hidpa=$("#hidpa").val();
    var cittype= $("#citizentype").val();
    var vtno=$("#vatno").val();
    var checkcy=vtno.substring(0,2);
    var flg=0;
    var havevatno=$("#hidvatno").val();
    if ((checkcy=="CY") || (checkcy=="cy")){
        flg=1;
    }
    if (cittype==2){
        //alert(hidvatper);
        //alert(hidpa);
        var hidfullpay=hidpa-hidvatper;
        //alert(hidfullpay);
    }else{
        if (flg==1){
var hidfullpay=hidpa;
        }else if(havevatno==2){
            var hidfullpay=hidpa;
        }else{
        var hidfullpay=hidpa-hidvatper;
        }
        //alert("citi"+hidfullpay);
    }
    $("#hidfullpay").val(hidfullpay);
        
        }else{
            
            
         var hidvatper=$("#hidvatper").val();
    var hidpabal=$("#hiddendbalamt").val();
    var cittype= $("#citizentype").val();
    var vtno=$("#vatno").val();
    var checkcy=vtno.substring(0,2);
    var flg=0;
    var havevatno=$("#hidvatno").val();
    if ((checkcy=="CY") || (checkcy=="cy")){
        flg=1;
    }
    if (cittype==2){
        //alert(hidvatper);
        //alert(hidpa);
        var hidfullpay=hidpabal-hidvatper;
        //alert(hidfullpay);
    }else{
        if (flg==1){
var hidfullpay=hidpabal;
        }else if(havevatno==2){
            var hidfullpay=hidpabal;
        }else{
        var hidfullpay=hidpabal-hidvatper;
        }
        //alert("citi"+hidfullpay);
    }
    //alert(hidfullpay);
    $("#hdbalamt").val(hidfullpay);
     
            
            
            
            
            
        }
        
        
        
        
        
        
        //new code
        
        
        
        
        
        if(fname != '' && title != '' && email != '' && mobile != '' && password != '' && password == confirmPassword && vatno==revatno)
        {
            $(".nextmod1, .nextmod").hide();
            $(".nextmod2, .nextmod22, .nextmod21").show();
        }
        else
        {
            return false;
        }
    }); 
    $(".nextmod22").click(function(){
        $(".nextmod1, .nextmod").show();
        $(".nextmod2, .nextmod22, .nextmod21").hide();
        var isdischeck = $("#discheck").is(":checked");
        if (isdischeck){
            	$(".secform").show();
        }
        else{
            	$(".secform").hide();
        }
        
        
        
    });  
    $("#fullpa, #fullpa1comt, #fullpa1, #fullpa1comt1, #fullpa11, #ful").hide();
    function showhavingvatno(){
     $(".eudiv").show();
     $("#hidvatno").val(1);
 }
 function hidehavingvatno(){
     $(".eudiv").hide();
     $("#hidvatno").val(2);
 }
    function show1()
    {
        $("#fullpaymenttype").val(1);
        
        var hidvatper=$("#hidvatper").val();
    var hidpa=$("#hidpa").val();
    var cittype= $("#citizentype").val();
    var vtno=$("#vatno").val();
    var checkcy=vtno.substring(0,2);
    var flg=0;
    var havevatno=$("#hidvatno").val();
    if ((checkcy=="CY") || (checkcy=="cy")){
        flg=1;
    }
    if (cittype==2){
        //alert(hidvatper);
        //alert(hidpa);
        var hidfullpay=hidpa-hidvatper;
        //alert(hidfullpay);
    }else{
        if (flg==1){
var hidfullpay=hidpa;
        }else if(havevatno==2){
            var hidfullpay=hidpa;
        }else{
        var hidfullpay=hidpa-hidvatper;
        }
        //alert("citi"+hidfullpay);
    }
    $("#hidfullpay").val(hidfullpay);
        document.getElementById('fullpa').style.display ='block';
        document.getElementById('fullpa1comt').style.display = 'none';
        document.getElementById('fullpa1').style.display = 'none';
        document.getElementById('fullpa1comt1').style.display = 'none';
        document.getElementById('fullpa11').style.display = 'none';
    }
    function show2()
    {
        
         $("#fullpaymenttype").val(2);
         var hidvatper=$("#hidvatper").val();
    var hidpabal=$("#hiddendbalamt").val();
    var cittype= $("#citizentype").val();
    var vtno=$("#vatno").val();
    var checkcy=vtno.substring(0,2);
    var flg=0;
    var havevatno=$("#hidvatno").val();
    if ((checkcy=="CY") || (checkcy=="cy")){
        flg=1;
    }
    if (cittype==2){
        //alert(hidvatper);
        //alert(hidpabal);
        var hidfullpay=hidpabal-hidvatper;
        //alert(hidfullpay);
    }else{
        if (flg==1){
var hidfullpay=hidpabal;
        }else if(havevatno==2){
            var hidfullpay=hidpabal;
        }else{
        var hidfullpay=hidpabal-hidvatper;
        }
        //alert("citi"+hidfullpay);
    }
    //alert(hidfullpay);
    $("#hdbalamt").val(hidfullpay);
     
        
        
        document.getElementById('fullpa').style.display ='none';
        document.getElementById('fullpa1comt').style.display = 'block';
        document.getElementById('fullpa1').style.display = 'block';
        document.getElementById('fullpa1comt1').style.display = 'block';
        document.getElementById('fullpa11').style.display = 'block';
    }
    function show3()
    {
        document.getElementById('ful').style.display ='block';
    }
    $('.block').smoove({
        offset: '10%'
    });
    $(document).on("click", ".btnallcookies", function () {
        $(".cookiesbg").fadeOut();
    })
    
    
      $('form').submit( function(event) {
    var formId = this.id,
        form = this;
    //alert("entered me");

    event.preventDefault();

    setTimeout( function () { 
        form.submit();
    }, 5000);
}); 
    
    
    function subfrmevent(){
    //alert("enter dismiss");
    $(".popmodalfrmevent").submit();
    
}
    
    
    
</script>