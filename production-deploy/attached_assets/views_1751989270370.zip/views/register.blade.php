<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width" />
    <link rel="shortcut icon" href="{{ url('/content/image/favicon.png') }}" type="image/png" sizes="36x36">
    <link href="{{ url('/content/css/EUZ.min.css') }}" rel="stylesheet" />
    <link href="{{ url('/content/css/styleEUZ.css') }}" rel="stylesheet" />
    <link href="{{ url('/content/css/font-awesome/css/all.css') }}" rel="stylesheet" />
    <script src="{{ url('/content/js/jquery-2.2.0.min.js') }}"></script>
    <script src="{{ url('/content/js/slick.js') }}"></script>
    <script src="{{ url('/content/js/popper.min.js') }}"></script>
    <script src="{{ url('/content/js/bootstrap.min.js') }}"></script>
	<script>
		/*$(function () {			
			$(".anavelink").css({ "color": "#626262" });
			var sPageURL = window.location.search.substring(0);

			alert($('.anavelink').attr('sPageURL'));
			$("#home").css({ "color": "#4599c3" });
		});*/		
	</script>
    <title>{{ $settings[0]->seo_title }}</title> 
</head>
<body>	
	@include('header')
    <div class="minhei">        
		<div class="container">
			<div class="row p-4">
				<div class="col-md-4">
					<h3 class="headforh">Registration</h3>
				</div>
				<div class="col-md-12">
					@if(session()->has('reg'))
						<div class="alert alert-success">
							{{ session()->get('reg') }}
						</div>
					@endif
				</div>
				<div class="col-md-12">
					@if(session()->has('regfail'))
						<div class="alert alert-danger">
							{{ session()->get('regfail') }}
						</div>
					@endif
				</div>				
				<div class="col-md-12 mt-4 inbglightblue p-4">
					<form class="row py-4" method="post" action="{{ url('/user/store') }}">
						{{ csrf_field() }}
						<div class="form-group col-md-6">
							<label for="">Full Name1</label>
							<input type="text" class="form-control" id="" name="name" required />
						</div>
						<div class="form-group col-md-6">
							<label for="">Address</label>
							<input type="text" class="form-control" id="" name="address" required />
						</div>               
						<div class="form-group col-md-6">
							<label for="">City</label>
							<input type="text" class="form-control" id="" name="city" required />
						</div>
						<div class="form-group col-md-6">
							<label for="">State</label>
							<input type="text" class="form-control" id="" name="state" required />
						</div>                
						<div class="form-group col-md-6">
							<label for="">Country/Region</label>
							<input type="text" class="form-control" id="" name="country" required />
						</div>
						<div class="form-group col-md-6">
							<label for="">Mobile Number</label>
							<input type="text" class="form-control" id="" name="mobile" required />
						</div>
						<div class="form-group col-md-6">
							<label for="">Email</label>
							<input type="email" class="form-control" id="" name="email" required />
						</div>
						<div class="form-group col-md-6">
							<label for="">Password</label>
							<input type="text" class="form-control" id="" name="password" required />
						</div>
						<div class="form-group col-md-12">
							<input type="submit" class="btn btn-custom" id="btnCreate" value="Create" name="create" />&nbsp;
							<input type="button" class="btn btn-custom" id="btnCancel" value="Cancel">
						</div>
					</form>
				</div>      
			</div>
		</div>
    </div>
	@include('footer')  	
</body>
</html>



