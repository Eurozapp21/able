<div class="modal fade" id="register" tabindex="-1" role="dialog" aria-labelledby="" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered euz_model_lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="">Registration Form</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form class="popmodalfrm" method="post" action="{{ url('/store') }}" onSubmit="return popmodal();">
                {{ csrf_field() }}
                <div class="modal-body">
                    <div class="row border p-3 m-2 nextmod1">
                        <div class="col-md-12">
                            <h5 class="font-weight-bold" id="">Participant Details</h5><hr>
                        </div>
                        <input type="hidden" name="headingtype" value="1" />
                        <input type="hidden" name="headingid" value="<?php echo $seminar[0]->id; ?>" />
                        <!-- Name Fields -->
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="fname">Name</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" class="form-control" id="fname" name="fname" required />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="lname">Surname</label>
                            <input type="text" class="form-control" id="lname" name="lname" />
                        </div>
                        <!-- Job Title and Discipline Fields -->
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="job_title">Job Title</label><span style="color: #fbdc00;"> *</span>
                            <select id="job_title" name="job_title" class="form-control" required>
                                <option value="" disabled selected>Select your job title</option>
                                <option value="Speech Language Pathologists">Speech Language Pathologists</option>
                                <option value="Occupational Therapists">Occupational Therapists</option>
                                <option value="Registered Dietitians">Registered Dietitians</option>
                                <option value="Special Education Teachers">Special Education Teachers</option>
                                <option value="Psychologists">Psychologists</option>
                                <option value="Physical Therapists">Physical Therapists</option>
                                <option value="Early Intervention Specialists">Early Intervention Specialists</option>
                                <option value="Nurses">Nurses</option>
                                <option value="Physicians">Physicians</option>
                                <option value="Mental Health Workers">Mental Health Workers</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                        <div class="form-group col-lg-4 col-md-6" id="custom_job_title_div" style="display:none;">
                            <label for="custom_job_title">Custom Job Title</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" id="custom_job_title" name="custom_job_title" class="form-control">
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="discipline">Discipline</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" id="discipline" name="discipline" class="form-control" required>
                        </div>
                        <!-- Company and Address Fields -->
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="org">Company/ Org</label>
                            <input type="text" class="form-control" id="org" name="org" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="address">Address</label>
                            <input type="text" class="form-control" id="address" name="address" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="city">City</label>
                            <input type="text" class="form-control" id="city" name="city" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="postcode">Postal code</label>
                            <input type="text" class="form-control" id="postcode" name="postcode" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="country">Country</label>
                            <input type="text" class="form-control" id="country" name="country" />
                        </div>
                        <!-- Contact Information Fields -->
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="phone">Tel.</label>
                            <input type="text" class="form-control IsNumberFields" id="phone" name="phone" onkeypress="return isNumberKey(event)" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="fax">Fax</label>
                            <input type="text" class="form-control" id="fax" name="fax" />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="mobile">Mobile</label><span style="color: #fbdc00;"> *</span>
                            <input type="text" class="form-control" id="mobile" name="mobile" required onkeypress="return isNumberKey(event)"/>
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="email">Email</label><span style="color: #fbdc00;"> *</span>
                            <input type="email" class="form-control IsEmailFields" id="email" name="email" required />
                        </div>
                        <!-- Password Fields -->
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="txtPassword">Password</label><span style="color: #fbdc00;"> *</span>
                            <input type="password" class="form-control" id="txtPassword" name="pass" required />
                        </div>
                        <div class="form-group col-lg-4 col-md-6">
                            <label for="txtConfirmPassword">Re-Enter Password</label><span style="color: #fbdc00;"> *</span>
                            <input type="password" class="form-control" id="txtConfirmPassword" name="conpass" />
                        </div>
                    </div>
                    <!-- Additional Questions/Special Requests Section -->
                    <div class="row border p-3 m-2 nextmod1">
                        <div class="col-md-12">
                            <h5 class="font-weight-bold" id="">Additional Questions/Special Requests</h5><hr>
                        </div>
                        <div class="form-group col-lg-12 col-md-3">
                            <label for="accommodations"><b>1. Accommodations, Dietary Requirements and Special Requests:</b> <br> If you require special accommodations or need assistance, please contact Abletools at least two weeks in advance of the conference at <a href="mailto:info@abletools.com.cy">info@abletools.com.cy</a> or +357 22 250 115.</label>
                        </div>
                        <div class="form-group col-lg-12 col-md-9">
                            <!--<textarea class="form-control" id="accommodations" name="accommodations" rows="3"></textarea> -->
                        </div>
                        <div class="form-group col-lg-4 col-md-3">
                            <label for="severe_allergies"><b>2. Specialty Dietary Requirements* </b><br>Do you have any severe / life threatening food allergies that would impact your attendance at the conference? (Yes or No). If you responded yes, please explain:</label>
                        </div>
                        <div class="form-group col-lg-8 col-md-9">
                            <textarea class="form-control" id="severe_allergies" name="severe_allergies" rows="3"></textarea>
                        </div>
                        <div class="form-group col-lg-4 col-md-3">
                            <label for="dietary_preferences"><b>3. Non-Severe/Life Threatening Dietary Preferences* </b><br> If you have dietary preferences, please explain: </label>
                        </div>
                        <div class="form-group col-lg-8 col-md-9">
                            <textarea class="form-control" id="dietary_preferences" name="dietary_preferences" rows="3"></textarea>
                        </div>
                        <div class="form-group col-lg-12 col-md-12">
                            <p>Please note, we will offer a variety of food selections during our morning and afternoon breaks, including protein and fruit items. While we will strive to provide options for those with dietary preferences, we are unable to guarantee that the food provided will meet all preferences. For those with specific preferences, you are welcome to bring additional snacks to ensure that they meet your dietary preferences and to supplement the food provided.</p>
                        </div>
                    </div>
                    <!-- Payment Method Section -->
                    <div class="row border p-3 m-2 nextmod2">
                        <div class="col-md-12">
                            <h5 class="font-weight-bold" id="">Payment Method</h5><hr>
                        </div>
                        <div class="col-lg-8 pad0">
                            <div class="form-group col-lg-12 col-md-4">
                                <!--
                                <div class="custom-control custom-radio custom-control-inline" onclick="show3();" style="display: none;">
                                    <input type="radio" class="custom-control-input cash" id="customRadio" name="tratype" value="Cash Payment" required>
                                    <label class="custom-control-label" for="customRadio">Cash Payment</label>
                                </div>
                                -->
                                <div class="custom-control custom-radio custom-control-inline" onclick="show3();">
                                    <input type="radio" class="custom-control-input bank" id="customRadio2" name="tratype" value="Bank Transaction">
                                    <label class="custom-control-label" for="customRadio2">Bank Transaction</label>
                                </div>
                                <div class="form-group col-lg-12 col-md-12 bankdis" style="display: none;">
                                    <label for="">Bank Transaction Details</label>
                                    <textarea type="text" class="form-control" id="" rows="5" name="" readonly><?php echo $seminar[0]->bank; ?></textarea>
    
                                </div>
                                <!--
                                <div class="custom-control custom-radio custom-control-inline" onclick="show3();" style="display: none;">
                                    <input type="radio" class="custom-control-input online" id="customRadio3" name="tratype" value="Online">
                                    <label class="custom-control-label" for="customRadio3">Online</label>
                                </div>
                                -->
                            </div>
                            <div class="form-group col-lg-12" id="ful">
                                <div class="custom-control custom-radio custom-control-inline" onclick="show1();">
                                    <input type="radio" class="custom-control-input" id="fullamount" name="paytype" value="Full Payment" required>
                                    <label class="custom-control-label" for="fullamount">Full Payment</label>
                                </div>
                                <?php if(!empty($seminar[0]->firstamt)) {?>
                                <div class="custom-control custom-radio custom-control-inline" onclick="show2();">
                                    <input type="radio" class="custom-control-input" id="halfamount" name="paytype" value="Half Payment">
                                    <label class="custom-control-label" for="halfamount">Deposit</label>
                                </div>
                                <?php } ?>
                            </div>
                            <div class="form-group col-lg-4 col-md-6" id="fullpa">
                                <label for="">Full Payment</label>
                                <input type="hidden" id="hidpa" value="<?php echo number_format((float)$payableamt, 2, '.', '');?>" />
                                <input type="hidden" id="hidvatper" value="<?php echo round($vatper,2) ;?>" />
                                <input type="hidden" id="citizentype" value="" />
                                <input type="hidden" id="hidvatno" value="" />
                                <input type="hidden" id="fullpaymenttype" value="" />
                                <input type="text" class="form-control" id="hidfullpay" name="fullamt" value="" readonly>
                                <input type="hidden" class="form-control" id="" name="ids" value="<?php echo $seminar[0]->id; ?>">
                                <input type="hidden" class="form-control" id="" name="page" value="Seminar">
                                <input type="hidden" class="form-control" id="" name="title" value="<?php echo $seminar[0]->title; ?>">
                            </div>
                            <div class="form-group col-lg-4 col-md-6" id="fullpa1">
                                <b for="" class="font-weight">Half Payment</b>
                                <input type="text" class="form-control" id="" name="halfamt" value="<?php echo $seminar[0]->firstamt;  ?>" readonly>
                            </div>
                            <div class="form-group col-lg-12 col-md-12" id="fullpa1comt">
                                <p class="text-justify mb-0"><?php if(!empty($seminar[0]->fee)) { echo $seminar[0]->firstdesc; } ?></p>
                            </div>
                            <div class="form-group col-lg-4 col-md-6" id="fullpa11">
                                <b for="" class="font-weight">Balance Standing Amount</b>
                                <input type="hidden" class="form-control" id="hiddendbalamt" name="balamt" value="<?php if(!empty($seminar[0]->fee)) { 
                                echo number_format((float)$balamt, 2, '.', ''); } ?>" readonly>
                                <input type="text" class="form-control" id="hdbalamt" name="balamt" value="" readonly>
                            </div>
                            <div class="form-group col-lg-12 col-md-12" id="fullpa1comt1">
                                <p class="text-justify"><?php if(!empty($seminar[0]->fee)) { echo $seminar[0]->seconddesc; } ?></p>
                            </div>
                        </div>
                        <!-- Citizenship Fields -->
                        <div class="form-group col-lg-12 col-md-12">
                            <div class="form-group col-lg-4 col-md-3">
                                <input type="radio" class="" id="eushow" name="citi" required value="EU Citizen" />
                                <label for="" class="ml-2">EU Citizen</label>
                                <span style="color: #fbdc00;"> *</span>
                            </div>
                            <div class="form-group col-lg-4 col-md-9 yesno">
                                <label class="mr-2 euz_wi">Do you have Vat Number?</label>
                                <input type="radio" class="" id="eushowyes" name="dovatno" value="1" onclick="showhavingvatno()" />
                                <label for="" class="ml-2">Yes</label>
                                <span style="color: #fbdc00;"> *</span>
                                <input type="radio" class="" id="eushowno" name="dovatno" value="2" onclick="hidehavingvatno()" />
                                <label for="" class="ml-2">No</label>
                                <span style="color: #fbdc00;"> *</span>
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <input type="radio" class="" id="euhide" name="citi" required value="Non-EU Citizen" />
                                <label for="" class="ml-2">Non-EU Citizen</label>
                                <span style="color: #fbdc00;"> *</span>
                            </div>
                        </div>
                        <!--
                        <div class="col-lg-4 form-group cashdis" style="display: none;">
                            <label for="">Cash Payment Details</label>
                            <textarea type="text" class="form-control" id="" rows="5" name=""><?php echo $seminar[0]->cash; ?></textarea>    
                        </div>
                        -->
                        <!--
                        <div class="col-lg-4 form-group onlinedis" style="display: none;">
                            <img class="img-fluid w-50" src="<?php echo url('/../Content/image/paypal.png'); ?>" />  
                        </div>
                        -->
                        <div class="form-group col-lg-12">
                            <label for="comment">Comment</label>
                            <textarea type="text" class="form-control" id="comment" rows="5" name="comment"></textarea>
                        </div>
                        <!-- Invoice Checkbox -->
                        <div class="col-md-12">
                            <input type="checkbox" name="discheck" id="discheck" style="margin-left: 10px;" /> I need invoice
                        </div>
                        <!-- Invoice Information Section (Moved Here) -->
                        <div class="row border p-3 m-2 nextmod1 secform" style="display: none;">
                            <div class="col-md-12">
                                <h5 class="font-weight-bold" id="">Στοιχεία Τιμολογίου / Invoice Information</h5><hr>
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <label for="orgname">Organization Name</label>
                            </div>
                            <div class="form-group col-lg-8 col-md-9">
                                <input type="text" class="form-control" id="orgname" name="orgname">
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <label for="address1">Address 1</label>
                            </div>
                            <div class="form-group col-lg-8 col-md-9">
                                <input type="text" class="form-control" id="address1" name="address1">
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <label for="address2">Address 2</label>
                            </div>
                            <div class="form-group col-lg-8 col-md-9">
                                <input type="text" class="form-control" id="address2" name="address2">
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <label for="day">Others</label>
                            </div>
                            <div class="form-group col-lg-8 col-md-9">
                                <input type="text" class="form-control" id="day" name="day">
                            </div>
                            <div class="form-group col-lg-4 col-md-3">
                                <label for="occu">Occupation</label>
                            </div>
                            <div class="form-group col-lg-8 col-md-9">
                                <input type="text" class="form-control" id="occu" name="occu">
                            </div>
                        </div>
                    </div>
                    <!-- Terms and Conditions Section -->
                    <div class="row border p-3 m-2 nextmod1 termsdiv" style="display:none;">
                        <div class="col-md-12">
                            <h5 class="font-weight-bold" id="">Terms and Conditions</h5><hr>
                        </div>
                        <div class="col-md-12">
                            <?php echo $seminar[0]->terms; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="display: flow-root;">
                    <input type="checkbox" name="terms" id="terms" style="margin-left: 10px;" class="chkag"  />I Accept Terms and Conditions
                    <button type="button" class="btn btn-cardbutn ml-2" data-dismiss="modal" style="border-radius: 50px;">Cancel</button>
                    <button type="button" class="btn btn-cardbutn ml-2 nextmod subterms" style="display: none;">Next</button>
                    <button type="button" class="btn btn-cardbutn ml-2 nextmod22">Back</button>
                    <button type="submit" class="btn btn-cardbutn ml-2 nextmod21" id="btnSubmit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Existing JavaScript

    document.getElementById('job_title').addEventListener('change', function() {
        var customJobTitleDiv = document.getElementById('custom_job_title_div');
        if (this.value === 'other') {
            customJobTitleDiv.style.display = 'block';
            document.getElementById('custom_job_title').required = true;
        } else {
            customJobTitleDiv.style.display = 'none';
            document.getElementById('custom_job_title').required = false;
        }
    });

    $('#register').on('hidden.bs.modal', function () {
        $(this).find("input[type=checkbox]").prop("checked", "");
    });

    $(".yesno").hide();
    $(".eudiv").hide();
    $(document).ready(function() {
        $("#eushow").click(function(){
            $("#citizentype").val(1);
            $(".yesno").show();
        });
        $("#euhide").click(function(){
            $("#citizentype").val(2);
            $(".eudiv").hide();
            $(".yesno").hide();
            $("#vatno, #revatno").removeAttr('required');
        });
        $("#eushowyes").click(function(){
            $(".eudiv").show();
        });
        $("#eushowno").click(function(){
            $(".eudiv").hide();
            $("#vatno, #revatno").removeAttr('required');
        });

        $('#terms').change(function() {
            if($(this).is(":checked")) {
                $(".termsdiv").show();
            } else {
                $(".termsdiv").hide();
            }
        });

        $('#discheck').change(function() {
            if($(this).is(":checked")) {
                $(".secform").show();
            } else {
                $(".secform").hide();
            }
        });

        $('.cash').click(function() {
            if ($(this).is(":checked")) {
                $(".cashdis").show();
                $(".bankdis, .onlinedis").hide();
            } 
        });

        $('.bank').click(function() {
            if ($(this).is(":checked")) {
                $(".bankdis").show();
                $(".cashdis, .onlinedis").hide();
            } 
        });

        $('.online').click(function() {
            if ($(this).is(":checked")) {
                $(".onlinedis").show();
                $(".cashdis, .bankdis").hide();
            } 
        });

        $(".nextmod").click(function() {
            var fname = $("#fname").val();
            var title = $("#title").val();
            var mobile = $("#mobile").val();
            var email = $("#email").val();
            var password = $("#txtPassword").val();
            var vatno = $("#vatno").val();
            var revatno = $("#revatno").val();
            var confirmPassword = $("#txtConfirmPassword").val();

            if(fname == '') {
                alert("Name field is required.");
                return false;
            }
            if(title == '') {
                alert("Title field is required.");
                return false;
            }
            if(mobile == '') {
                alert("Mobile field is required.");
                return false;
            }
            if(email == '') {
                alert("Email field is required.");
                return false;
            }
            if(password == '') {
                alert("Password field is required.");
                return false;
            }
            if(password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            if(vatno != revatno) {
                alert("VAT Number does not match.");
                return false;
            }

            if(fname != '' && title != '' && email != '' && mobile != '' && password != '' && password == confirmPassword && vatno == revatno) {
                $(".nextmod1, .nextmod").hide();
                $(".nextmod2, .nextmod22, .nextmod21").show();
            } else {
                return false;
            }
        });

        $(".nextmod22").click(function(){
            $(".nextmod1, .nextmod").show();
            $(".nextmod2, .nextmod22, .nextmod21").hide();
            if ($("#discheck").is(":checked")) {
                $(".secform").show();
            } else {
                $(".secform").hide();
            }
        });

        $("#fullpa, #fullpa1comt, #fullpa1, #fullpa1comt1, #fullpa11, #ful").hide();
    });

    function showhavingvatno() {
        $(".eudiv").show();
        $("#hidvatno").val(1);
    }

    function hidehavingvatno() {
        $(".eudiv").hide();
        $("#hidvatno").val(2);
        $("#vatno, #revatno").removeAttr('required');
    }

    function show1() {
        $("#fullpaymenttype").val(1);
        var hidvatper = $("#hidvatper").val();
        var hidpa = $("#hidpa").val();
        var cittype = $("#citizentype").val();
        var vtno = $("#vatno").val();
        var checkcy = vtno.substring(0,2);
        var flg = 0;
        var havevatno = $("#hidvatno").val();
        if ((checkcy == "CY") || (checkcy == "cy")) {
            flg = 1;
        }
        if (cittype == 2) {
            var hidfullpay = hidpa - hidvatper;
        } else {
            if (flg == 1 || havevatno == 2) {
                var hidfullpay = hidpa;
            } else {
                var hidfullpay = hidpa - hidvatper;
            }
        }
        $("#hidfullpay").val(hidfullpay);
        $("#fullpa").show();
        $("#fullpa1comt, #fullpa1, #fullpa1comt1, #fullpa11").hide();
    }

    function show2() {
        $("#fullpaymenttype").val(2);
        var hidvatper = $("#hidvatper").val();
        var hidpabal = $("#hiddendbalamt").val();
        var cittype = $("#citizentype").val();
        var vtno = $("#vatno").val();
        var checkcy = vtno.substring(0,2);
        var flg = 0;
        var havevatno = $("#hidvatno").val();
        if ((checkcy == "CY") || (checkcy == "cy")) {
            flg = 1;
        }
        if (cittype == 2) {
            var hidfullpay = hidpabal - hidvatper;
        } else {
            if (flg == 1 || havevatno == 2) {
                var hidfullpay = hidpabal;
            } else {
                var hidfullpay = hidpabal - hidvatper;
            }
        }
        $("#hdbalamt").val(hidfullpay);
        $("#fullpa1comt, #fullpa1, #fullpa1comt1, #fullpa11").show();
        $("#fullpa").hide();
    }

    function show3() {
        $("#ful").show();
    }

    function isNumberKey(evt) {
        var charCode = (evt.which) ? evt.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;
        return true;
    }

    function popmodal(){
        var email = $("#email").val();
        $('.txtemail').html(email);
        var fname = $("#fname").val();
        $('.txtname').html(fname);
        $('#confirmmodal').modal('show');
    }

    $('form').submit( function(event) {
        var formId = this.id,
            form = this;

        event.preventDefault();

        setTimeout( function () { 
            form.submit();
        }, 5000);
    }); 

    function subfrm(){
        $(".popmodalfrm").submit();
    }
</script>
