<h2>Newsletter Consent Form</h2>
<p>This is a test page.</p>
